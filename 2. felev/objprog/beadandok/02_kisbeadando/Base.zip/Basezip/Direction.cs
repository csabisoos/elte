namespace HF1;

public record Direction()
{
    public int x { get; set; }
    public int y { get; set; }
}