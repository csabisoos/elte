namespace HF1;

public enum Content
{
    Empty,
    Wall,
    Ghost,
    Treasure
}