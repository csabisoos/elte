namespace _06_kisbeadando
{
    public class Termek
    {
        public string Cikkszam { get; set; }
        public int Ar { get; set; }
    }
}

