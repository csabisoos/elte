namespace HF4
{
    public class Element
    {
        public int pr;
        public string data;

        public Element(int priority, string value)
        {
            pr = priority;
            data = value;
        }
    }
}

