namespace HF8
{
    public abstract class Registration
    {
        public abstract int GetSize();
    }
}

