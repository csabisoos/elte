namespace HF10
{
    public interface Size
    {
        public int Multi();
    }
}

