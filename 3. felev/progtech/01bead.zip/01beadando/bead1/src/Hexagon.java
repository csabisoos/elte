public class Hexagon extends Polygon {
    // Constructors
    public Hexagon(double x, double y, double side) {
        super(x, y, side);
    }

    // Methods
    @Override
    protected int sideNum() {
        return 6;
    }
}